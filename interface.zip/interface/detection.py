import streamlit as st
import pandas as pd
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
import base64

# ----------- CONFIGURATION ------------
st.set_page_config(page_title="Détection d'intrusion", layout="wide", page_icon=":lock:")

# ----------- CSS PERSONNALISÉ ----------
st.markdown("""
    <style>
    .main {
        background-color: #f4f6f9;
        font-family: 'Segoe UI', sans-serif;
    }
    .stButton>button {
        background-color: #007bff;
        color: white;
        font-size: 16px;
        border-radius: 8px;
        padding: 10px 20px;
        transition: 0.3s;
    }
    .stButton>button:hover {
        background-color: #0056b3;
    }
    .stTabs [data-baseweb="tab"] {
        font-size: 18px;
        font-weight: bold;
        color: #007bff;
    }
    .footer {
        text-align: center;
        padding: 20px;
        margin-top: 50px;
        font-size: 14px;
        color: #888;
    }
    </style>
""", unsafe_allow_html=True)

# ----------- MODELS ------------
MODELS_PATH = "C:\\Users\\HP\\Desktop\\MonDossier\\"
models = {
    "Random Forest": joblib.load(MODELS_PATH + "model_rf.joblib"),
    "DT": joblib.load(MODELS_PATH + "model_dt.joblib"),
    "RL": joblib.load(MODELS_PATH + "model_rl.joblib"),
    "NB": joblib.load(MODELS_PATH + "model_nb.joblib"),
    "XGboost": joblib.load(MODELS_PATH + "model_xgb.joblib"),
    "LightGBM": joblib.load(MODELS_PATH + "model_lgbm.joblib")
}
features = joblib.load(MODELS_PATH + "features.joblib")


# ----------- NAVIGATION PRINCIPALE -----------
tabs = st.tabs(["🏠 Accueil", "🧪 Prédiction Manuelle", "📂 Prédiction CSV"])

# ----------- ONGLET ACCUEIL ------------
with tabs[0]:
    col1, col2, col3 = st.columns([1, 6, 1])
    with col1:
        st.image("https://www.fsb.univh2c.ma/wp-content/uploads/2020/01/logo-fsbVF.png", width=150)
    with col3:
        st.image("logo.png", width=130)

    st.markdown("<h1 style='text-align: center; color: navy;'>Détection des Attaques Réseau</h1>", unsafe_allow_html=True)
    st.markdown("<h4 style='text-align: center; color: #444;'>Projet de Fin d'Études - 2025 | univh2c ben m'sik</h4>", unsafe_allow_html=True)
    st.markdown("<h4 style='text-align: center; color: #444;'>Application de prédiction basée sur l'AA</h4>", unsafe_allow_html=True)
    st.markdown("""
        <p style='text-align: center; font-size:16px; color:#333;'>
        Ce projet utilise plusieurs modèles de machine learning pour détecter les intrusions dans le trafic réseau.
        Vous pouvez tester manuellement ou via un fichier CSV.
        </p>
    """, unsafe_allow_html=True)

# ----------- ONGLET PRÉDICTION MANUELLE -----------
with tabs[1]:
    st.subheader("🧪 Prédiction Manuelle")

    user_input = {}
    col1, col2, col3 = st.columns(3)

    with col1:
        user_input['dur'] = st.number_input("Durée de la connexion", step=0.1)
        user_input['sbytes'] = st.number_input("Octets envoyés (sbytes)", step=1.0)
        user_input['is_ftp_login'] = st.selectbox("Connexion FTP réussie ?", [0, 1])

    with col2:
        user_input['dbytes'] = st.number_input("Octets reçus (dbytes)", step=1.0)
        user_input['ct_srv_src'] = st.number_input("Connexions du même service", step=1.0)
        user_input['hour'] = st.slider("Heure de la connexion", 0, 23, 12)

    with col3:
        user_input['Stime'] = st.number_input("Temps de début (Stime)", step=1.0)
        user_input['ct_state_ttl'] = st.number_input("Flux même état/TTL", step=1.0)
        user_input['ct_dst_ltm'] = st.number_input("Connexions vers le même hôte", step=1.0)

    if st.button("🔍 Lancer la prédiction manuelle"):
        input_df = pd.DataFrame([user_input])
        for col in features:
            if col not in input_df.columns:
                input_df[col] = 0
        input_df = input_df[features]

        for model_name, model in models.items():
            try:
                prediction = model.predict(input_df)
                result = "🛑 Attaque détectée !" if prediction[0] == 1 else "✅ Connexion normale"
                st.markdown(f"<div style='padding:10px;background-color:#f0f8ff;border-radius:10px;margin-bottom:10px'><b>{model_name} :</b> {result}</div>", unsafe_allow_html=True)
            except Exception as e:
                st.error(f"Erreur avec le modèle {model_name} : {e}")

# ----------- ONGLET CSV ------------
with tabs[2]:
    st.subheader("📂 Prédiction via Fichier CSV")

    uploaded_file = st.file_uploader("Choisir un fichier .csv", type="csv")

    if uploaded_file:
        df = pd.read_csv(uploaded_file)

        if 'hour' not in df.columns and 'Stime' in df.columns:
            try:
                df['hour'] = pd.to_datetime(df['Stime'], unit='s').dt.hour
                st.info("Colonne 'hour' ajoutée à partir de 'Stime'.")
            except Exception as e:
                st.warning(f"Erreur de conversion Stime → hour : {e}")

        missing = [f for f in features if f not in df.columns]
        if missing:
            st.error(f"Colonnes manquantes : {missing}")
        else:
            if st.button("📊 Lancer la prédiction sur le CSV"):
                for model_name, model in models.items():
                    try:
                        predictions = model.predict(df[features])
                        df[f"Prediction_{model_name}"] = ["Attack" if p == 1 else "Normal" for p in predictions]
                        st.success(f"{model_name} : Prédictions terminées")
                    except Exception as e:
                        st.error(f"Erreur avec le modèle {model_name} : {e}")

            st.markdown("### Aperçu des résultats :")
            st.dataframe(df.head(10))

            st.subheader("📈 Graphique des prédictions")
            if "Prediction_Random Forest" in df.columns:
                attack_count = df['Prediction_Random Forest'].value_counts()
                fig, ax = plt.subplots(figsize=(4,2))
                ax.pie(attack_count, labels=attack_count.index, autopct='%1.1f%%', startangle=90)
                ax.axis('equal')
                st.pyplot(fig)

            def download_csv(df):
                csv = df.to_csv(index=False)
                b64 = base64.b64encode(csv.encode()).decode()
                href = f'<a href="data:file/csv;base64,{b64}" download="predictions.csv">📥 Télécharger le fichier CSV</a>'
                return href

            st.markdown(download_csv(df), unsafe_allow_html=True)

# ----------- FOOTER ------------
st.markdown("""
    <div class="footer">
        © 2025 YOUMOULOUD Zaineb & MHADA Hiba – Tous droits réservés.<br>
        Sous la supervision de Mme BENABBOU Faouzia & Mme ZAOUI Chaimae <br>
        Projet universitaire – Université Hassan II Casablanca Ben M'Sik
    </div>
""", unsafe_allow_html=True)
